# Approximate Largest Inscribed Rectangle algorithms

## Key Findings
The primary algorithm identified is a heuristic approach for finding the largest axis-aligned inscribed rectangle in a general polygon, as described in the paper "Algorithm for finding the largest inscribed rectangle in polygon" by Zahraa Marzeh, Maryam Tahmasbi, and Narges Mirehi. This algorithm is implemented in the `largestinteriorrectangle` Python package. The algorithm works by first discretizing the polygon into a binary mask. It then iterates through all possible rectangles within the mask and checks if they are fully contained within the polygon. To optimize this process, it uses a summed-area table (also known as an integral image) to quickly calculate the area of any rectangular region. This allows for efficient checking of whether a rectangle is empty or not. While this method can handle non-convex polygons, it is limited to finding axis-aligned rectangles and may not be robust to significant noise or artistic elements, which is a key requirement for the target use case of finding the 'perceptually largest void' in decorative UI containers.

## Implementation Examples
```python
import largestinteriorrectangle as lir
import numpy as np

# Define a polygon
polygon = np.array([[[20,15],[210,30],[220,100],[20,100]]], np.int32)

# Find the largest inscribed rectangle
rectangle = lir.lir(polygon)

# The result is an array [x, y, width, height]
print(rectangle)
```

## Evaluation
| Criteria | Rating |
|---|---|
| Implementation Complexity | Easy (< 1 day) |
| Runtime Performance | Acceptable (50-100ms) |
| Robustness to Noise | Medium |

## Pros and Cons
*   **Pros:**
    *   Relatively simple to implement and use.
    *   Reasonably fast for many applications.
    *   Can handle non-convex polygons.
*   **Cons:**
    *   Only finds axis-aligned rectangles.
    *   May not be robust to significant noise or artistic elements.
    *   The brute-force nature of the search can be slow for very large polygons.

## Key Resources
*   [Algorithm for finding the largest inscribed rectangle in polygon](https://jac.ut.ac.ir/article_71280.html)
*   [largestinteriorrectangle Python package](https://github.com/linex-cd/rectinpolygon)
*   [Stack Overflow discussion](https://stackoverflow.com/questions/70362355/finding-largest-inscribed-rectangle-in-polygon)

## Recommendation
This approach is a good starting point for finding the largest inscribed rectangle in a polygon. However, for the specific use case of finding the "perceptually largest void" in a decorative UI container, it may not be sufficient due to its limitations in handling noise and non-axis-aligned rectangles. Further research into more robust and flexible algorithms is recommended.